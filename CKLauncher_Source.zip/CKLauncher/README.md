# CK Launcher

A custom Android HOME launcher based on the supplied Galaxy Z Fold launcher layout.

## Current v0.1 features
- Registers as an Android Home app.
- Immersive full-screen layout: no launcher status bar or Android navigation bar visible by default.
- Uses the phone's current wallpaper instead of baking the screenshot into the APK.
- Two clear glass clock/date widgets.
- Live right-side status widget: current time/date, Wi-Fi state, battery percentage/ring, four mobile-signal dots.
- Right vertical dock: Phone, Browser, Messages, Spotify.
- Clear app icons with no glass panel behind each app.
- Home page + swipe-to-all-apps page.
- Folders: Social, Work, Media, Tools; long-press any app to move it into a folder or create a new folder.
- Search button.
- Layout adapts between cover screen and unfolded display.

## Install/build
The included GitHub Actions workflow builds `app-debug.apk` automatically. After installing, press Home and choose **CK Launcher** as the default Home app.

## Notes
- Android may ask for Phone permission. It is only used to populate the four mobile signal dots.
- Wi-Fi and battery indicators use live Android system state.
- Some manufacturer-specific widgets and exact iOS/Safari artwork are not bundled; the launcher uses installed Android app icons.
