package com.ck.launcher;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private LauncherView launcherView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        hideSystemBars();
        launcherView = new LauncherView(this);
        setContentView(launcherView);
        requestPhonePermissionIfNeeded();
        maybePromptForDefaultHome();
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemBars();
        if (launcherView != null) launcherView.refreshApps();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    private void hideSystemBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    0x00000004 | // FULLSCREEN
                    0x00000002 | // HIDE_NAVIGATION
                    0x00001000 | // IMMERSIVE_STICKY
                    0x00000400 | // LAYOUT_FULLSCREEN
                    0x00000200 | // LAYOUT_HIDE_NAVIGATION
                    0x00000100   // LAYOUT_STABLE
            );
        }
    }

    private void requestPhonePermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_PHONE_STATE}, 42);
        }
    }

    private void maybePromptForDefaultHome() {
        boolean shown = getPreferences(MODE_PRIVATE).getBoolean("home_prompt_shown", false);
        if (shown) return;
        getPreferences(MODE_PRIVATE).edit().putBoolean("home_prompt_shown", true).apply();
        new AlertDialog.Builder(this)
                .setTitle("Set CK Launcher as Home")
                .setMessage("For the Home button to open this launcher, choose CK Launcher as your default Home app.")
                .setPositiveButton("Choose Home app", (d, w) -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
                    } catch (Exception e) {
                        startActivity(new Intent(Settings.ACTION_SETTINGS));
                    }
                })
                .setNegativeButton("Later", null)
                .show();
    }

    public void openFolderPicker(AppEntry app) {
        if (app == null) return;
        launcherView.showFolderAssignmentDialog(app);
    }
}
