package com.ck.launcher;

import android.content.Intent;
import android.graphics.drawable.Drawable;

public final class AppEntry {
    public final String label;
    public final String packageName;
    public final Drawable icon;
    public final Intent launchIntent;

    public AppEntry(String label, String packageName, Drawable icon, Intent launchIntent) {
        this.label = label;
        this.packageName = packageName;
        this.icon = icon;
        this.launchIntent = launchIntent;
    }
}
