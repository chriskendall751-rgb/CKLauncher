package com.ck.launcher;

import android.Manifest;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.text.InputType;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@SuppressWarnings("deprecation")
public class LauncherView extends View {
    private final MainActivity activity;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Handler clockHandler = new Handler(Looper.getMainLooper());
    private final PackageManager pm;
    private final SharedPreferences prefs;
    private final GestureDetector gestures;
    private final List<AppEntry> allApps = new ArrayList<>();
    private final List<Hit> hits = new ArrayList<>();
    private final LinkedHashMap<String, List<AppEntry>> folders = new LinkedHashMap<>();
    private final Map<String, AppEntry> byLabel = new HashMap<>();
    private final Map<String, AppEntry> byPackage = new HashMap<>();

    private int page = 0;
    private int batteryPct = 100;
    private int mobileLevel = 0;
    private int wifiLevel = 0;
    private boolean wifiConnected = false;
    private String openFolder = null;
    private String searchQuery = "";
    private PhoneStateListener phoneListener;
    private TelephonyManager telephony;
    private BroadcastReceiver batteryReceiver;

    private final String[] defaultFolderNames = {"Social", "Work", "Media", "Tools"};

    public LauncherView(MainActivity activity) {
        super(activity);
        this.activity = activity;
        this.pm = activity.getPackageManager();
        this.prefs = activity.getSharedPreferences("launcher_prefs", Context.MODE_PRIVATE);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        p.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.NORMAL));
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        gestures = new GestureDetector(activity, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }
            @Override public boolean onSingleTapUp(MotionEvent e) { return handleTap(e.getX(), e.getY()); }
            @Override public void onLongPress(MotionEvent e) { handleLongPress(e.getX(), e.getY()); }
            @Override public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                if (e1 == null || e2 == null) return false;
                float dx = e2.getX() - e1.getX();
                if (Math.abs(dx) > dp(80) && Math.abs(velocityX) > 500) {
                    openFolder = null;
                    page = dx < 0 ? 1 : 0;
                    invalidate();
                    return true;
                }
                return false;
            }
        });
        refreshApps();
        registerBattery();
        registerSignal();
        updateNetwork();
        clockHandler.post(clockTick);
    }

    private final Runnable clockTick = new Runnable() {
        @Override public void run() {
            updateNetwork();
            invalidate();
            clockHandler.postDelayed(this, 1000);
        }
    };

    public void refreshApps() {
        allApps.clear(); byLabel.clear(); byPackage.clear();
        Intent q = new Intent(Intent.ACTION_MAIN, null);
        q.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = pm.queryIntentActivities(q, 0);
        for (ResolveInfo ri : found) {
            String pkg = ri.activityInfo.packageName;
            if (activity.getPackageName().equals(pkg)) continue;
            CharSequence labelCs = ri.loadLabel(pm);
            String label = labelCs == null ? pkg : labelCs.toString();
            Intent launch = pm.getLaunchIntentForPackage(pkg);
            Drawable icon = ri.loadIcon(pm);
            AppEntry e = new AppEntry(label, pkg, icon, launch);
            allApps.add(e);
            byPackage.put(pkg, e);
            byLabel.put(label.toLowerCase(Locale.UK), e);
        }
        Collections.sort(allApps, Comparator.comparing(a -> a.label.toLowerCase(Locale.UK)));
        rebuildFolders();
        invalidate();
    }

    private void rebuildFolders() {
        folders.clear();
        for (String f : defaultFolderNames) folders.put(f, new ArrayList<>());
        String savedNames = prefs.getString("folder_names", "");
        if (!savedNames.isEmpty()) {
            for (String n : savedNames.split("\\|")) if (!n.trim().isEmpty() && !folders.containsKey(n)) folders.put(n, new ArrayList<>());
        }

        for (AppEntry app : allApps) {
            String assigned = prefs.getString("folder_" + app.packageName, "");
            if (!assigned.isEmpty()) {
                if (!folders.containsKey(assigned)) folders.put(assigned, new ArrayList<>());
                folders.get(assigned).add(app);
                continue;
            }
            String l = app.label.toLowerCase(Locale.UK);
            if (containsAny(l, "facebook", "whatsapp", "instagram", "messenger", "meta", "threads")) folders.get("Social").add(app);
            else if (containsAny(l, "outlook", "workday", "mars", "hours", "teams", "authenticator")) folders.get("Work").add(app);
            else if (containsAny(l, "spotify", "sonos", "youtube", "netflix", "prime video", "disney", "sky", "paramount")) folders.get("Media").add(app);
            else if (containsAny(l, "calculator", "clock", "settings", "weather", "files", "contacts", "1password")) folders.get("Tools").add(app);
        }
    }

    private boolean containsAny(String src, String... words) {
        for (String w : words) if (src.contains(w)) return true;
        return false;
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        clockHandler.removeCallbacks(clockTick);
        if (batteryReceiver != null) try { activity.unregisterReceiver(batteryReceiver); } catch (Exception ignored) {}
        if (telephony != null && phoneListener != null) try { telephony.listen(phoneListener, PhoneStateListener.LISTEN_NONE); } catch (Exception ignored) {}
    }

    private void registerBattery() {
        batteryReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                if (level >= 0 && scale > 0) batteryPct = Math.max(0, Math.min(100, Math.round(level * 100f / scale)));
                invalidate();
            }
        };
        activity.registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    }

    private void registerSignal() {
        telephony = (TelephonyManager) activity.getSystemService(Context.TELEPHONY_SERVICE);
        if (telephony == null) return;
        phoneListener = new PhoneStateListener() {
            @Override public void onSignalStrengthsChanged(SignalStrength s) {
                super.onSignalStrengthsChanged(s);
                try { mobileLevel = Math.max(0, Math.min(4, s.getLevel())); }
                catch (Throwable t) { mobileLevel = 0; }
                invalidate();
            }
        };
        try {
            if (Build.VERSION.SDK_INT < 23 || activity.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                telephony.listen(phoneListener, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS);
            }
        } catch (Exception ignored) {}
    }

    private void updateNetwork() {
        try {
            ConnectivityManager cm = (ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE);
            Network active = cm == null ? null : cm.getActiveNetwork();
            NetworkCapabilities caps = active == null || cm == null ? null : cm.getNetworkCapabilities(active);
            wifiConnected = caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
        } catch (Exception e) { wifiConnected = false; }
        wifiLevel = wifiConnected ? 4 : 0;
        if (wifiConnected) {
            try {
                WifiManager wm = (WifiManager) activity.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                WifiInfo info = wm == null ? null : wm.getConnectionInfo();
                if (info != null) wifiLevel = Math.max(1, Math.min(4, WifiManager.calculateSignalLevel(info.getRssi(), 5)));
            } catch (Exception ignored) {}
        }
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        hits.clear();
        boolean unfolded = getWidth() > getHeight() * 0.82f;
        drawTopWidgets(c, unfolded);
        drawStatusAndDock(c, unfolded);
        if (page == 0) drawHome(c, unfolded); else drawAllApps(c, unfolded);
        drawBottomNavigation(c, unfolded);
        if (openFolder != null) drawFolderOverlay(c, unfolded, openFolder);
    }

    private void drawTopWidgets(Canvas c, boolean unfolded) {
        float margin = dp(unfolded ? 34 : 24);
        float top = dp(unfolded ? 56 : 165);
        float boxW = dp(unfolded ? 190 : 138);
        float boxH = dp(unfolded ? 150 : 165);
        float gap = dp(12);
        float x = unfolded ? getWidth() * 0.43f : margin;

        glass(c, x, top, x + boxW, top + boxH, dp(28));
        glass(c, x + boxW + gap, top, x + boxW * 2 + gap, top + boxH, dp(28));

        p.setColor(Color.WHITE);
        p.setTextAlign(Paint.Align.LEFT);
        p.setTextSize(dp(unfolded ? 18 : 14));
        c.drawText("◷", x + dp(18), top + dp(28), p);
        p.setTextSize(dp(unfolded ? 45 : 35));
        c.drawText(timeText(), x + dp(18), top + dp(unfolded ? 86 : 82), p);
        p.setTextSize(dp(unfolded ? 15 : 12));
        c.drawText("Local time", x + dp(18), top + boxH - dp(20), p);

        float x2 = x + boxW + gap;
        p.setTextSize(dp(unfolded ? 16 : 13));
        c.drawText(dayText(), x2 + dp(18), top + dp(26), p);
        p.setTextSize(dp(unfolded ? 48 : 39));
        c.drawText(dayNumber(), x2 + dp(18), top + dp(unfolded ? 84 : 82), p);
        p.setTextSize(dp(unfolded ? 15 : 12));
        c.drawText(monthText(), x2 + dp(18), top + boxH - dp(20), p);
    }

    private void drawStatusAndDock(Canvas c, boolean unfolded) {
        float dockW = dp(unfolded ? 78 : 72);
        float right = getWidth() - dp(unfolded ? 38 : 20);
        float dockLeft = right - dockW;
        float statusCx = dockLeft + dockW / 2f;
        float statusTop = dp(unfolded ? 62 : 180);

        p.setColor(Color.WHITE);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(dp(unfolded ? 18 : 15));
        c.drawText(timeText(), statusCx, statusTop, p);
        p.setTextSize(dp(unfolded ? 12 : 11));
        c.drawText(shortDateText(), statusCx, statusTop + dp(23), p);

        float cy = statusTop + dp(unfolded ? 68 : 62);
        float radius = dp(unfolded ? 27 : 24);
        stroke.setStrokeWidth(dp(3.5f));
        stroke.setColor(0x66FFFFFF);
        c.drawArc(new RectF(statusCx - radius, cy - radius, statusCx + radius, cy + radius), 135, 270, false, stroke);
        stroke.setColor(Color.WHITE);
        c.drawArc(new RectF(statusCx - radius, cy - radius, statusCx + radius, cy + radius), 135, 270 * batteryPct / 100f, false, stroke);
        drawWifi(c, statusCx, cy - dp(2), wifiConnected ? wifiLevel : 0);
        drawSignalDots(c, statusCx, cy + dp(30));
        p.setTextSize(dp(unfolded ? 12 : 11));
        c.drawText(batteryPct + "%", statusCx, cy + dp(55), p);
        hits.add(new Hit(new RectF(statusCx - dp(42), statusTop - dp(15), statusCx + dp(42), cy + dp(65)), HitType.WIFI, null));

        float dockTop = cy + dp(unfolded ? 92 : 85);
        float dockH = dp(unfolded ? 300 : 290);
        glass(c, dockLeft, dockTop, right, dockTop + dockH, dockW / 2f);
        String[] dock = {"Phone", "Browser", "Messages", "Spotify"};
        for (int i = 0; i < dock.length; i++) {
            float cellH = dockH / 4f;
            float centerY = dockTop + cellH * (i + .5f);
            drawDockIcon(c, dock[i], statusCx, centerY, dp(unfolded ? 45 : 42));
            hits.add(new Hit(new RectF(dockLeft, dockTop + i * cellH, right, dockTop + (i + 1) * cellH), HitType.DOCK, dock[i]));
        }
    }

    private void drawWifi(Canvas c, float cx, float cy, int level) {
        stroke.setColor(level > 0 ? Color.WHITE : 0x77FFFFFF);
        stroke.setStrokeWidth(dp(3.5f));
        for (int i = 0; i < 3; i++) {
            float r = dp(8 + i * 6);
            if (level < i + 2) stroke.setColor(0x55FFFFFF); else stroke.setColor(Color.WHITE);
            c.drawArc(new RectF(cx - r, cy - r * .55f, cx + r, cy + r * 1.1f), 205, 130, false, stroke);
        }
        p.setColor(level > 0 ? Color.WHITE : 0x55FFFFFF);
        c.drawCircle(cx, cy + dp(12), dp(2.8f), p);
    }

    private void drawSignalDots(Canvas c, float cx, float cy) {
        float start = cx - dp(15);
        for (int i = 0; i < 4; i++) {
            p.setColor(i < mobileLevel ? Color.WHITE : 0x55FFFFFF);
            c.drawCircle(start + i * dp(10), cy, dp(2.8f), p);
        }
    }

    private void drawHome(Canvas c, boolean unfolded) {
        float left = unfolded ? getWidth() * 0.43f : dp(28);
        float top = unfolded ? dp(250) : dp(470);
        float rightLimit = getWidth() - dp(unfolded ? 150 : 112);
        int cols = unfolded ? 4 : 4;
        float gap = dp(unfolded ? 22 : 16);
        float cellW = (rightLimit - left - gap * (cols - 1)) / cols;
        float icon = Math.min(dp(unfolded ? 58 : 55), cellW * .72f);
        float rowH = dp(unfolded ? 108 : 98);

        List<Object> items = new ArrayList<>();
        items.add(findByHints("Facebook", "facebook"));
        items.add(findByHints("WhatsApp", "whatsapp"));
        items.add(findByHints("Calendar", "calendar"));
        items.add(findByHints("ChatGPT", "chatgpt", "openai"));
        items.add("Social"); items.add("Work"); items.add("Media"); items.add("Tools");
        items.add(findByHints("Camera", "camera"));
        items.add(findByHints("Photos", "photos", "gallery"));
        items.add(findByHints("Outlook", "outlook"));
        items.add(findByHints("Gmail", "gmail"));
        items.add(findByHints("Notes", "notes", "keep"));
        items.add(findByHints("Play Store", "play store"));
        items.add(findByHints("Hours Tracker", "hours tracker", "hours"));
        items.add(findByHints("MarsService", "marsservice", "mars service"));

        for (int i = 0; i < items.size(); i++) {
            int col = i % cols, row = i / cols;
            float cx = left + col * (cellW + gap) + cellW / 2f;
            float cy = top + row * rowH + icon / 2f;
            Object item = items.get(i);
            if (item instanceof AppEntry) drawApp(c, (AppEntry)item, cx, cy, icon, true);
            else if (item instanceof String) drawFolder(c, (String)item, cx, cy, icon);
        }
    }

    private void drawAllApps(Canvas c, boolean unfolded) {
        float left = dp(unfolded ? 30 : 22);
        float top = dp(unfolded ? 65 : 120);
        float rightLimit = getWidth() - dp(unfolded ? 150 : 112);
        int cols = unfolded ? 8 : 5;
        float gap = dp(unfolded ? 12 : 10);
        float cellW = (rightLimit - left - gap * (cols - 1)) / cols;
        float icon = Math.min(dp(unfolded ? 52 : 50), cellW * .74f);
        float rowH = dp(unfolded ? 92 : 88);
        int rowMax = Math.max(1, (int)((getHeight() - top - dp(80)) / rowH));
        int max = Math.min(allApps.size(), cols * rowMax);
        int shown = 0;
        for (AppEntry app : allApps) {
            if (!searchQuery.isEmpty() && !app.label.toLowerCase(Locale.UK).contains(searchQuery.toLowerCase(Locale.UK))) continue;
            if (shown >= max) break;
            int col = shown % cols, row = shown / cols;
            float cx = left + col * (cellW + gap) + cellW / 2f;
            float cy = top + row * rowH + icon / 2f;
            drawApp(c, app, cx, cy, icon, true);
            shown++;
        }
    }

    private void drawApp(Canvas c, AppEntry app, float cx, float cy, float size, boolean label) {
        if (app == null) return;
        Rect bounds = new Rect((int)(cx - size/2), (int)(cy - size/2), (int)(cx + size/2), (int)(cy + size/2));
        try { app.icon.setBounds(bounds); app.icon.draw(c); } catch (Exception ignored) {
            p.setColor(0xAAFFFFFF); c.drawRoundRect(new RectF(bounds), dp(12), dp(12), p);
        }
        if (label) {
            p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(dp(10.5f));
            c.drawText(ellipsize(app.label, 13), cx, cy + size/2 + dp(18), p);
        }
        hits.add(new Hit(new RectF(cx - size*.7f, cy - size*.7f, cx + size*.7f, cy + size*.9f + dp(20)), HitType.APP, app));
    }

    private void drawFolder(Canvas c, String name, float cx, float cy, float size) {
        RectF r = new RectF(cx-size/2, cy-size/2, cx+size/2, cy+size/2);
        p.setColor(0x38FFFFFF);
        c.drawRoundRect(r, dp(14), dp(14), p);
        stroke.setColor(0x55FFFFFF); stroke.setStrokeWidth(dp(1)); c.drawRoundRect(r, dp(14), dp(14), stroke);
        List<AppEntry> apps = folders.get(name);
        float mini = size * .32f;
        float off = size * .2f;
        for (int i=0; apps != null && i<4 && i<apps.size(); i++) {
            float mx = cx + (i%2==0?-off:off), my = cy + (i<2?-off:off);
            Drawable d = apps.get(i).icon;
            Rect b = new Rect((int)(mx-mini/2),(int)(my-mini/2),(int)(mx+mini/2),(int)(my+mini/2));
            try { d.setBounds(b); d.draw(c); } catch (Exception ignored) {}
        }
        p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(dp(10.5f));
        c.drawText(name, cx, cy+size/2+dp(18), p);
        hits.add(new Hit(new RectF(cx-size*.7f,cy-size*.7f,cx+size*.7f,cy+size*.9f+dp(20)), HitType.FOLDER, name));
    }

    private void drawDockIcon(Canvas c, String name, float cx, float cy, float size) {
        AppEntry app = dockApp(name);
        if (app != null && app.icon != null) {
            Rect b = new Rect((int)(cx-size/2),(int)(cy-size/2),(int)(cx+size/2),(int)(cy+size/2));
            try { app.icon.setBounds(b); app.icon.draw(c); return; } catch (Exception ignored) {}
        }
        p.setTextAlign(Paint.Align.CENTER); p.setTextSize(size*.55f); p.setColor(Color.WHITE);
        String glyph = name.equals("Phone") ? "☎" : name.equals("Browser") ? "◉" : name.equals("Messages") ? "✉" : "♪";
        c.drawText(glyph, cx, cy + size*.18f, p);
    }

    private void drawBottomNavigation(Canvas c, boolean unfolded) {
        float y = getHeight() - dp(44);
        p.setTextAlign(Paint.Align.CENTER);
        for (int i=0;i<2;i++) {
            p.setColor(i==page ? Color.WHITE : 0x66FFFFFF);
            c.drawCircle(getWidth()/2f + (i-.5f)*dp(28), y, dp(i==page?4:3), p);
        }
        p.setColor(Color.WHITE); p.setTextSize(dp(22)); c.drawText("☰", getWidth()/2f + dp(60), y+dp(7), p);
        hits.add(new Hit(new RectF(getWidth()/2f+dp(35), y-dp(25), getWidth()/2f+dp(90), y+dp(25)), HitType.PAGE, "apps"));
        p.setTextSize(dp(28));
        c.drawText("⌕", getWidth()-dp(unfolded?65:48), y+dp(7), p);
        hits.add(new Hit(new RectF(getWidth()-dp(95),y-dp(35),getWidth()-dp(10),y+dp(35)), HitType.SEARCH, null));
    }

    private void drawFolderOverlay(Canvas c, boolean unfolded, String name) {
        List<AppEntry> apps = folders.get(name);
        if (apps == null) return;
        float w = Math.min(getWidth()-dp(50), dp(unfolded?520:330));
        float h = Math.min(getHeight()-dp(140), dp(unfolded?430:500));
        float left = (getWidth()-w)/2f, top=(getHeight()-h)/2f;
        p.setColor(0xDD262626); c.drawRoundRect(new RectF(left,top,left+w,top+h),dp(28),dp(28),p);
        stroke.setColor(0x55FFFFFF); stroke.setStrokeWidth(dp(1)); c.drawRoundRect(new RectF(left,top,left+w,top+h),dp(28),dp(28),stroke);
        p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.LEFT);p.setTextSize(dp(22));c.drawText(name,left+dp(22),top+dp(38),p);
        p.setTextAlign(Paint.Align.RIGHT);p.setTextSize(dp(24));c.drawText("×",left+w-dp(20),top+dp(38),p);
        hits.add(new Hit(new RectF(left+w-dp(55),top,left+w,top+dp(60)),HitType.CLOSE,null));
        int cols = unfolded?5:4; float pad=dp(20), gap=dp(12); float cell=(w-pad*2-gap*(cols-1))/cols; float icon=Math.min(dp(54),cell*.72f); float rowH=dp(95);
        for(int i=0;i<apps.size();i++) {
            int col=i%cols,row=i/cols; float cx=left+pad+col*(cell+gap)+cell/2; float cy=top+dp(70)+row*rowH+icon/2;
            if(cy+icon/2>top+h-dp(20)) break;
            drawApp(c,apps.get(i),cx,cy,icon,true);
        }
    }

    private void glass(Canvas c, float l, float t, float r, float b, float radius) {
        p.setColor(0x38FFFFFF); c.drawRoundRect(new RectF(l,t,r,b),radius,radius,p);
        stroke.setColor(0x55FFFFFF); stroke.setStrokeWidth(dp(1)); c.drawRoundRect(new RectF(l,t,r,b),radius,radius,stroke);
    }

    private boolean handleTap(float x, float y) {
        for (int i=hits.size()-1;i>=0;i--) {
            Hit h=hits.get(i); if(!h.rect.contains(x,y)) continue;
            switch(h.type) {
                case APP: launch((AppEntry)h.data); break;
                case FOLDER: openFolder=(String)h.data; invalidate(); break;
                case CLOSE: openFolder=null; invalidate(); break;
                case WIFI: try { activity.startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); } catch(Exception ignored){} break;
                case DOCK: launchDock((String)h.data); break;
                case SEARCH: showSearch(); break;
                case PAGE: page=1; openFolder=null; invalidate(); break;
            }
            return true;
        }
        if(openFolder!=null){openFolder=null;invalidate();return true;}
        return false;
    }

    private void handleLongPress(float x,float y){
        for(int i=hits.size()-1;i>=0;i--){Hit h=hits.get(i);if(h.rect.contains(x,y)&&h.type==HitType.APP){activity.openFolderPicker((AppEntry)h.data);return;}}
    }

    public void showFolderAssignmentDialog(AppEntry app) {
        List<String> options = new ArrayList<>(folders.keySet()); options.add("+ New folder"); options.add("Remove from folder");
        new AlertDialog.Builder(activity).setTitle("Folder for " + app.label).setItems(options.toArray(new String[0]), (d,which)->{
            String selected=options.get(which);
            if(selected.equals("+ New folder")){showNewFolderDialog(app);return;}
            SharedPreferences.Editor ed=prefs.edit();
            if(selected.equals("Remove from folder")) ed.remove("folder_"+app.packageName); else ed.putString("folder_"+app.packageName,selected);
            ed.apply(); rebuildFolders(); invalidate();
        }).show();
    }

    private void showNewFolderDialog(AppEntry app){
        EditText input=new EditText(activity);input.setHint("Folder name");input.setSingleLine(true);
        new AlertDialog.Builder(activity).setTitle("New folder").setView(input).setPositiveButton("Create",(d,w)->{
            String n=input.getText().toString().trim();if(n.isEmpty())return;
            String names=prefs.getString("folder_names",""); if(!Arrays.asList(names.split("\\|")).contains(n)) prefs.edit().putString("folder_names",names.isEmpty()?n:names+"|"+n).apply();
            prefs.edit().putString("folder_"+app.packageName,n).apply();rebuildFolders();invalidate();
        }).setNegativeButton("Cancel",null).show();
    }

    private void showSearch(){
        final EditText input=new EditText(activity);input.setHint("Search apps");input.setSingleLine(true);input.setInputType(InputType.TYPE_CLASS_TEXT);
        new AlertDialog.Builder(activity).setTitle("Search apps").setView(input).setPositiveButton("Search",(d,w)->{searchQuery=input.getText().toString().trim();page=1;invalidate();}).setNeutralButton("Show all",(d,w)->{searchQuery="";page=1;invalidate();}).setNegativeButton("Cancel",null).show();
    }

    private void launch(AppEntry app){if(app==null||app.launchIntent==null)return;try{activity.startActivity(app.launchIntent);}catch(Exception ignored){}}

    private void launchDock(String name){
        try{
            if(name.equals("Phone")){activity.startActivity(new Intent(Intent.ACTION_DIAL));return;}
            if(name.equals("Browser")){activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")));return;}
            if(name.equals("Messages")){activity.startActivity(new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:")));return;}
            if(name.equals("Spotify")){AppEntry s=dockApp("Spotify");if(s!=null)launch(s);else activity.startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://open.spotify.com")));}
        }catch(Exception ignored){}
    }

    private AppEntry dockApp(String name){
        if(name.equals("Spotify"))return byPackage.get("com.spotify.music");
        if(name.equals("Browser"))return findByHints("Browser","chrome","internet","browser");
        if(name.equals("Messages"))return findByHints("Messages","messages","messaging");
        if(name.equals("Phone"))return findByHints("Phone","phone","dialer");
        return null;
    }

    private AppEntry findByHints(String preferred,String...hints){
        AppEntry exact=byLabel.get(preferred.toLowerCase(Locale.UK));if(exact!=null)return exact;
        for(AppEntry e:allApps){String l=e.label.toLowerCase(Locale.UK);for(String h:hints)if(l.contains(h.toLowerCase(Locale.UK)))return e;}return null;
    }

    private String ellipsize(String s,int max){return s.length()<=max?s:s.substring(0,Math.max(1,max-1))+"…";}
    private String timeText(){return new SimpleDateFormat("H:mm",Locale.UK).format(new Date());}
    private String dayText(){return new SimpleDateFormat("EEEE",Locale.UK).format(new Date());}
    private String dayNumber(){return new SimpleDateFormat("d",Locale.UK).format(new Date());}
    private String monthText(){return new SimpleDateFormat("MMMM",Locale.UK).format(new Date());}
    private String shortDateText(){return new SimpleDateFormat("MMM d",Locale.UK).format(new Date());}
    private float dp(float v){return v*getResources().getDisplayMetrics().density;}

    @Override public boolean onTouchEvent(MotionEvent event){return gestures.onTouchEvent(event)||super.onTouchEvent(event);}

    private enum HitType { APP,FOLDER,CLOSE,WIFI,DOCK,SEARCH,PAGE }
    private static final class Hit { final RectF rect; final HitType type; final Object data; Hit(RectF r,HitType t,Object d){rect=r;type=t;data=d;} }
}
